# Lesson 5.7 Compound Conditionals!

A Pen created on CodePen.

Original URL: [https://codepen.io/Keyon-Pendergrass/pen/vEBXKLm](https://codepen.io/Keyon-Pendergrass/pen/vEBXKLm).

